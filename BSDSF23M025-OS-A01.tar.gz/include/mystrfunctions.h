int mystrlen(const char* s);
int mystrcpy(char* dest, const char* src);
int mystrncpy(char* dest, const char* src, int n);
int mystrcat(char* dest, const char* src);

